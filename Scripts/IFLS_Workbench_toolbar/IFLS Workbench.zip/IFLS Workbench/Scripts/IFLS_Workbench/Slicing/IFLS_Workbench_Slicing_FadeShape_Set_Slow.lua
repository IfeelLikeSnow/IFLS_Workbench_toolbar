-- @description IFLS Workbench: Slicing FadeShape Set – Slow (10/14 ms)
-- @version 1.0
local set = dofile((reaper.GetResourcePath().."/Scripts/IFLS_Workbench/Slicing/_IFLS_Slicing_FadeCommon.lua"))
set("slow", 10, 14)
