-- @description IFLS Workbench: Slicing FadeShape Set – Fast (2/5 ms)
-- @version 1.0
local set = dofile((reaper.GetResourcePath().."/Scripts/IFLS_Workbench/Slicing/_IFLS_Slicing_FadeCommon.lua"))
set("fast", 2, 5)
